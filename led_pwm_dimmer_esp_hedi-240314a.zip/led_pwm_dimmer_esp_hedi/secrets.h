#define SECRET_SSID "Ziggo9516352"
#define SECRET_PASS "ndsmtwKpn6qr"
#define MQTTSERVER "192.168.178.30"
#define MQTTPORT 1883
